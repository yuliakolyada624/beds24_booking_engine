<?php
/**
 * Beds24
 */

define('BEDS_API_KEY', 'bb5ab368-1da3-4b27-bf39-6c6629a4c171');
define('BEDS_PROP_KEY', '2007a7293cd4a78b8bba7e1a2854bb');

define('BEDS_USER', 'vidbackenb');
define('BEDS_REF_TOKEN','muePaPd1jx8DOOhxl+2GU2Oa9fvUygk5wM4Da5cXXd10B0lgUmsCCUXePpfpN8oUkOuUrlnOIrra8LcXSZvql7N1FfVWGa++KKHLLHaLII+rgJwkXOXRLEGhZdKT9NHhCuIpegC2pzVwMKyBv9S+jDCX3jkG6VW8ZpZ22GPw2Ic=');
