(function( $ ) {
    'use strict';
    var $ = jQuery;
    $(".upd-prop").on('click', function () {
        console.log('ok')
    })
})